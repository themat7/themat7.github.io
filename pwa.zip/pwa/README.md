# hello-world-pwa

This is a super simple hello world progressive web app (PWA) deployed with Firebase.

It includes push notification, which isn't required in a PWA, but it's cool.

Check out the hosted version here: [https://hello-world-pwa-8669c.firebaseapp.com/](https://hello-world-pwa-8669c.firebaseapp.com/)
